# Pyslick 2.0 — Architecture & Developer Guide

> **Core Philosophy:** High-accuracy local semantic code navigation, call-graph comprehension, compound query decomposition, and context packing for potato PCs (Ryzen 3 / 8GB RAM CPU). Local operations find and extract exact functions with zero hallucinations, while complex reasoning & editing are packed for web LLMs (DeepSeek, Claude Web) or opened directly in VS Code (`code -g`).

---

## 1. System Architecture

```
                                  [ User Query in PowerShell ]
                                               │
                                               ▼
                              ┌──────────────────────────────────┐
                              │  Compound Query Decomposition    │
                              │  (decompose.py splits on 'and',  │
                              │   'also', ';', '?' into clauses) │
                              └────────────────┬─────────────────┘
                                               │
                                               ▼
                              ┌──────────────────────────────────┐
                              │  Universal Startup Auto-Graphify │
                              │  (Ensures graphify-out/graph.json│
                              │   via code-only extraction)      │
                              └────────────────┬─────────────────┘
                                               │
                                               ▼
                        ┌──────────────────────────────────────────────┐
                        │   Stage 1: Fast Candidate Retriever (Top 20) │
                        ├──────────────────────────────────────────────┤
                        │ • Custom BM25 Index (text_index.py)          │
                        │ • PageRank God-Nodes & Repomap (repomap.py)  │
                        │ • AST Symbol Graph (graphify.py)             │
                        │ • RapidFuzz String & Token Matching          │
                        └──────────────────────┬───────────────────────┘
                                               │
                                               ▼
                        ┌──────────────────────────────────────────────┐
                        │   Stage 2: Semantic Cross-Encoder Reranker   │
                        ├──────────────────────────────────────────────┤
                        │ • CPU-optimized ONNX Cross-Encoder           │
                        │ • Scores Natural Language Query vs Symbols   │
                        │ • 100% Deterministic & Hallucination-Free    │
                        └──────────────────────┬───────────────────────┘
                                               │
                                               ▼
                        ┌──────────────────────────────────────────────┐
                        │       Tree-Sitter AST Scope Snapper          │
                        ├──────────────────────────────────────────────┤
                        │ • Expands hit line to full enclosing function│
                        │ • Multi-language AST: TS, TSX, JS, PY, RS    │
                        │ • Never outputs arbitrary 8-line cutoffs     │
                        └──────────────────────┬───────────────────────┘
                                               │
                                               ▼
                        ┌──────────────────────────────────────────────┐
                        │                  Outputs                     │
                        ├──────────────────────────────────────────────┤
                        │ 1. Terminal: Ranked function blocks + ranges │
                        │ 2. VS Code: `code -g filepath:line`          │
                        │ 3. Clipboard: Hierarchical DeepSeek/Web LLM  │
                        │    Context Bundle (.pyslick_context/)        │
                        │ 4. BFS Paths: Connection paths for relations │
                        └──────────────────────────────────────────────┘
```

---

## 2. Directory Layout & Module Responsibilities

```
pyslick_package/pyslick_pkg/pyslick/
│
├── __init__.py            ← CLI entry point, argument parsing & dispatch
├── agent.py               ← Agentic workflow & fallback router
├── recon.py               ← Guided recon & multi-language module inspector
├── recon_semantic.py      ← 2-stage hybrid semantic search engine
├── recon_pack.py          ← Multi-clause context bundler for DeepSeek / Claude Web
├── query.py               ← Fast AST symbol & dependency lookup
├── repomap.py             ← PageRank repo overview, import scanner & AST tag extractor
├── decompose.py           ← Multi-clause NLP decomposition ('A and B', 'A; B')
├── relations.py           ← Graph BFS pathfinder between files/symbols
├── toolbox.py             ← mode_ls, mode_lines, mode_grep & code launcher
├── text_index.py          ← In-memory BM25 indexer over comments/strings/JSX
├── graphify.py            ← Local Python AST caller/callee graph builder
├── graphify_sitter.py     ← Tree-sitter AST extraction for TS/TSX
├── find_nearest_nodes.py  ← Fuzzy & graph traversal across graphify-out
├── find_stray_symbols.py  ← Unmatched JSX/TSX tag scanner
├── indentation.py         ← Scope & brace balance validator
├── jsx_tag_checker.py     ← Deep JSX/HTML tag hierarchy checker
├── synonyms.py            ← Semantic domain vocabulary & query expansion
├── autoloop.py            ← Command testing & auto-verification loop
├── clipboard.py           ← Instant stdout capture & clipboard synchronization
└── watch.py               ← Project watcher for `# pyslick?` review tags
```

---

## 3. Key Upgrades & Features (v0.3.4)

### A. Compound Query Decomposition (`decompose.py`)
- Automatically breaks complex multi-part queries like `"where is supabase client and how is cache registered"` into subqueries:
  1. `where is supabase client`
  2. `how is cache registered`
- Executes candidate searches across each subquery and unions results with ranked AST function blocks.

### B. Codebase Architecture Overview
- Queries like `"what does this codebase do"`, `"architecture overview"`, or `"explain repo"` trigger PageRank God-Node analysis.
- Extracts top connected files, entry points (`src/app/page.tsx`, `src/sw.ts`, `main.py`), and opening file docstrings to provide an instant architectural summary.

### C. Dependency & Import Scanning (`pyslick deps [target]`)
- Scans `package.json`, `pyproject.toml`, `Cargo.toml`, etc., along with all source code imports (`.ts`, `.tsx`, `.js`, `.py`, `.go`, `.rs`).
- Pinpoints exactly where dependencies (e.g. `serwist`, `supabase`, `next`) are imported across the codebase with line numbers.

### D. 2-Stage Hybrid Semantic Search (`pyslick grep "<concept>"`)
- **Stage 1 (Filter)**: In-memory BM25 (with 2.5x boosted docstrings/comments) + AST node labels collect candidate code regions.
- **Stage 2 (Rerank)**: Fast ONNX Cross-Encoder evaluates query semantics against candidate docstrings, comments, and signatures.
- **AST Enclosure**: Every match automatically snaps to its enclosing function end-to-end via Tree-Sitter (`repomap.py`).

### E. Relationship Resolution (`relations.py`)
- Queries like `"how does auth connect to database"` compute BFS connection paths through imports and call graphs.

### F. Universal Auto-Graphify
- Running any command in a fresh repository automatically verifies if `graphify-out/graph.json` exists.
- If missing, it transparently triggers `graphify extract . --code-only` once with status feedback.

---

## 4. CLI Command Reference

| Command | Description |
|---|---|
| `pyslick "what does this codebase do"` | Architecture overview: God-nodes, connectivity degree, opening architectural comments |
| `pyslick grep "<query>"` | Semantic hybrid search finding nearest functions end-to-end (supports compound `and` queries) |
| `pyslick grep <file> <pattern> [--context N]` | Exact pattern/regex search inside a file with AST function expansion |
| `pyslick recon "<directive>"` | Guided code inspection & component isolation pipeline |
| `pyslick recon-pack "<directive>"` | Pack complete context into `.pyslick_context/` and clipboard for DeepSeek Web |
| `pyslick deps [target]` / `pyslick imports` | Scan manifests and source files for imported external libraries and usage lines |
| `pyslick query "<directive>"` | Fast non-LLM symbol & caller/callee lookup |
| `pyslick ls [root]` | Clean grouped directory listing (skipping dependencies & build artifacts) |
| `pyslick lines <file> [range]` | View file with line numbers (e.g. `10-50` or `--head 20`) |
| `pyslick indentation <file>` | Validate scope alignment and `{}` brace balance |
| `pyslick jsx-check <file>` | Comprehensive JSX/HTML tag hierarchy validation |
| `pyslick find-stray-symbols <path>` | Scan a `.tsx`/`.jsx` file or entire folder for stray/unclosed tags |
| `pyslick copy` | Copy last command output to Windows clipboard |
